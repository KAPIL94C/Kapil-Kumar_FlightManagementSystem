package snippet;

public class Snippet {
	C:\Users\kapil chaudhary\Documents\FlightManagementSystem1\src\main\resources
}

