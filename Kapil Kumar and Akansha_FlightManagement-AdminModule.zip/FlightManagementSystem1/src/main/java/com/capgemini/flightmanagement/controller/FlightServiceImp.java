package com.capgemini.flightmanagement.controller;

import java.util.Scanner;

import com.capgemini.flightmanagement.dao.FlightDaoImp;
import com.capgemini.flightmanagement.model.Flight;
import com.capgemini.flightmanagement.ui.MainClass;

public class FlightServiceImp {
	
	public void  adminWork() {
		Scanner sc=new Scanner(System.in);
		FlightDaoImp   flightServiceObj=new FlightDaoImp();
		Flight flight;
		System.out.println("\n\n*****************************************************************************");
		System.out.println("------------------------------WELCOME ADMIN!!!!------------------------------");
        System.out.println("*****************************************************************************");
					System.out.println("Enter your choice:");
					System.out.println("1. Add Flight:");
					System.out.println("2. Schedule A Flight");
					System.out.println("3. Search A Flight");
					System.out.println("4. Search Scheduled Flight");
					System.out.println("5. View Flight Available");
					System.out.println("6. View Scheduled Flight");
					System.out.println("7. Delete Scheduled Flight");
					System.out.println("8. Logout");
				
					int n=0;
					try {
						 n=sc.nextInt();
						
						
						}catch(Exception e) {
							System.out.println("****************Enter Numeric Value**************************");
							this.adminWork();  
						}
		
		
		switch(n){
		
		case 1:
					flight=new Flight();
					flightServiceObj.addFlight(flight);
					this.adminWork();
					break;
		case 2:		Integer flightId=0;
					System.out.println("Enter the Flight Id:");
					try {
					 flightId=sc.nextInt();
					flightServiceObj.scheduleFlight(flightId);
					}catch(Exception e) {
						System.out.println("****************Enter Numeric Value**************************");
						this.adminWork();  
					}
					this.adminWork();
					break;
					
		case 3:     System.out.println("Enter the Flight Number:");
		            Integer b=0;
		            try {
		            b=sc.nextInt();
						flightServiceObj.searchFlight(b);
		            }catch(Exception e) {
						System.out.println("****************Enter Numeric Value**************************");
						this.adminWork();  
					}
		            this.adminWork();
					break;
		case 4:		System.out.println("Enter the Flight Number:");
        			Integer c=0;
        			try {
        			c=sc.nextInt();
        			flightServiceObj.searchScheduledFlight(c);
        			 }catch(Exception e) {
 						System.out.println("****************Enter Numeric Value**************************");
 						this.adminWork();  
 					}
        			this.adminWork();
					break;
		case 5:
					flightServiceObj.viewFlight();
					this.adminWork();
					break;
		case 6:      
					flightServiceObj.viewScheduledFlight();
					this.adminWork();
			
					break;
		case 7:     System.out.println("Enter the Flight Number:");
					Integer d=0;
					try{
						d=sc.nextInt();
					flightServiceObj.deleteFlight(d);
					 }catch(Exception e) {
							System.out.println("****************Enter Numeric Value**************************");
							this.adminWork();  
						}
					this.adminWork();
					break;
		case 8:     
						System.out.println("You Are Successfully LoggedOut");
						System.out.println("---------------------------------------------------\n\n\n");
			         MainClass main=new MainClass();
			         main.loginPage();
			         
			        
					break;
	    default :
	    			System.out.println("You Enter the Wrong choice:");
	    			this.adminWork();
	    			sc.nextLine();
		}
		
	}

}

