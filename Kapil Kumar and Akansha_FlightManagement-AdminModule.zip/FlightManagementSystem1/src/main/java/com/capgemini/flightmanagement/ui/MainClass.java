package com.capgemini.flightmanagement.ui;

import java.util.Scanner;

import com.capgemini.flightmanagement.controller.FlightServiceImp;
import com.capgemini.flightmanagement.dao.FlightDaoImp;
import com.capgemini.flightmanagement.model.UserLogin;

public class MainClass {
	public static void main(String[] args) {
		
	MainClass main=new MainClass();
	main.loginPage();
	}
	
	public void loginPage() {
		Scanner sc=new Scanner(System.in);
		UserLogin us=new UserLogin();
		us.addUser();
		System.out.println("------------------------------------------------------------");
		System.out.println("                     WELCOME TO HOME PAGE                   ");
		System.out.println("------------------------------------------------------------");
		System.out.println("Enter your Choice :");
		System.out.println("1. Admin Login");
		System.out.println("2. view flight");
		int n=0;
		
		try {
		 n=sc.nextInt();
		
		
		}catch(Exception e) {
			System.out.println("****************Enter Numeric Value**************************");
			this.loginPage();   
		}
		
		
		
		switch(n) {
		
		case 1: 	System.out.println("Enter the userName:");
					String user=sc.next();
					System.out.println("Enter the password :");
					String pass=sc.next();
					if(us.AdminValidate(user, pass)) {
					System.out.println("Valid User:");
					FlightServiceImp  flightDao=new FlightServiceImp();
					flightDao.adminWork();
				
					}
					else 
					{
						System.out.println("Wrong UseName or Password:");
					}
			
			break;
		case 2:
			FlightDaoImp    dao=new FlightDaoImp();
			dao.viewScheduledFlight();
			this.loginPage();
			break;
		default : 	
					System.out.println("You Enter the wrong choice ");
					this.loginPage();
		}
		
		
	}
	

}
