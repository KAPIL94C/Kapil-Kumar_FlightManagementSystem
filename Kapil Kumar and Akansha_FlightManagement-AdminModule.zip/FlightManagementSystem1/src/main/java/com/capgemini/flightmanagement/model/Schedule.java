package com.capgemini.flightmanagement.model;

import java.io.Serializable;
import java.util.Date;

public class Schedule implements Serializable {

	
	private String sourceAirport;
	private String destinationAirport;
	private Date arrivalTime;
	private Date departureTime;
	private double ticketCost;
	public Schedule() {
		super();
	}
	
	
	
	public String getSourceAirport() {
		return sourceAirport;
	}
	public void setSourceAirport(String sourceAirport) {
		this.sourceAirport = sourceAirport;
	}
	public String getDestinationAirport() {
		return destinationAirport;
	}

	public void setDestinationAirport(String destinationAirport) {
		this.destinationAirport = destinationAirport;
	}
	public double getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}
	public Date getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public Date getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}



	@Override
	public String toString() {
		return "[sourceAirport=" + sourceAirport + ", destinationAirport=" + destinationAirport
				+ ", arrivalTime=" + arrivalTime + ", departureTime=" + departureTime + ", ticketCost=" + ticketCost
				+ "]";
	}



	



	
	
	
	
	
	

}
