package com.capgemini.flightmanagement.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.capgemini.flightmanagement.location.info.LocationInfo;
import com.capgemini.flightmanagement.model.Airport;
import com.capgemini.flightmanagement.model.Flight;
import com.capgemini.flightmanagement.model.Schedule;
import com.capgemini.flightmanagement.model.ScheduledFlight;
import com.capgemini.flightmanagement.model.User;

import java.util.Scanner;

public class FlightDaoImp {
	Scanner sc = new Scanner(System.in);
	Schedule schedule;

	HashMap<Integer, Flight> mapFlight = new HashMap();
	HashMap<Integer, ScheduledFlight> scheduleList = new HashMap();
	ArrayList<Flight> list = new ArrayList();

	
	public void addFlight(Flight flight)
	{
		System.out.println("Enter the  flight no.");
		Integer no=0;
		try 
		{
			no = sc.nextInt();
		}catch(Exception e)
		{
			System.out.println("Flight no. should be Numeric:");
			return;
		}
			flight.setFlightNumber(no);
			sc.nextLine();

		System.out.println("Enter Flight Model");
		String m = sc.nextLine();
		flight.setFlightModel(m);

		System.out.println("Enter Flight Name");
		String n = sc.nextLine();
		flight.setCarrierName(n);

		System.out.println("Enter  seat capacity");
		Integer c=0;
		try
		{
		c = sc.nextInt();
		if(c>500)
			throw new ArithmeticException();
		}catch(ArithmeticException a) 
		{
			System.out.println("Seat Capacity should be less than 500");
			return;
		}catch(Exception e) 
		{
			System.out.println("Enter the seat capacity in digit:");
			return;
		}
		
		flight.setSeatCapacity(c);

		// this.serializationFlight(mapFlight);         //for putting null in file

		this.flightFile(flight);

	}

	public static void serializationFlight(HashMap<Integer, Flight> hm) {
		File path = new File(LocationInfo.pathFligth);
		FileOutputStream fos = null;
		ObjectOutputStream out = null;
		try {
			fos = new FileOutputStream(path);
			out = new ObjectOutputStream(fos);
			out.writeObject(hm);
			fos.close();
			out.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public HashMap<Integer, Flight> deserilizationFlight() {

		HashMap<Integer, Flight> hm = null;
		try {
			File path = new File(LocationInfo.pathFligth);

			FileInputStream fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			hm = (HashMap<Integer, Flight>) in.readObject();

		} catch (Exception e) {
			System.out.println(e);
		}

		return hm;

	}

	public void flightFile(Flight flight) {

		HashMap<Integer, Flight> hm = null;
		hm = this.deserilizationFlight();
		// System.out.println(hm);

		hm.put(flight.getFlightNumber(), flight);
		this.serializationFlight(hm);

		System.out.println("Flight Added Successfuly!!");

	}

	public void searchFlight(Integer b) {

		HashMap<Integer, Flight> hm = this.deserilizationFlight();
		System.out.println("ID      NAME     MODEL      CAPACITY");
		for (Map.Entry m : hm.entrySet()) {
			
			if (m.getKey().equals(b)) {
				Flight flight = (Flight) m.getValue();
				System.out.println("" + flight.getFlightNumber() + "   " + flight.getCarrierName() + "     "
						+ flight.getFlightModel() + "   " + flight.getSeatCapacity());
				return;

			}
		}

		System.out.println("Flight do not exists:");

	}

	public void viewFlight() {

		HashMap<Integer, Flight> hm = this.deserilizationFlight();
		System.out.println("ID      NAME     MODEL      CAPACITY");
		for (Map.Entry m : hm.entrySet()) {

			Flight flight = (Flight) m.getValue();
			System.out.println("" + flight.getFlightNumber() + "   " + flight.getCarrierName() + "     "
					+ flight.getFlightModel() + "   " + flight.getSeatCapacity());

		}

	}

	// -----------------------------------------------------------SCHEDULE
	// FLIGHT-----------------------
	public void scheduleFlight(Integer flightId) {

		Flight flight = null;
		Airport airport = null;
		int flag = 0;
		Schedule schedule = new Schedule();
		ScheduledFlight scheduleflight = new ScheduledFlight();
		HashMap<Integer, Flight> hm = this.deserilizationFlight(); // to check flight is available or not

		for (Map.Entry m : hm.entrySet()) {
			if (m.getKey().equals(flightId)) {
				flight = (Flight) m.getValue();
				flag = 1;
			}
		}
		if (flag == 0) {
			System.out.println("Flight do not exists:");
			return;

		}

		scheduleflight.setFlight(flight);

		System.out.println("Enter the source Airport");
		String source = sc.nextLine();
		schedule.setSourceAirport(source);

		System.out.println("Enter the destination Airport");
		String destination = sc.nextLine();
		schedule.setDestinationAirport(destination);

		System.out.println("Enter the ticket cost");
		Integer cost=0;
		try {
		cost = sc.nextInt();
		
		sc.nextLine();
		}
		catch(Exception e) {
			System.out.println("****************Enter Numeric Value**************************");
		    return;
		}
		schedule.setTicketCost(cost);
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		System.out.print("ENTER Arrival DATE STRING (dd-MM-yyyy): ");
		String arrivalDate = sc.nextLine();

		System.out.print("ENTER departure DATE STRING (dd-MM-yyyy ): ");
		String departureDate = sc.nextLine();

		try {

			// Parse the date
			Date date = df.parse(df.format(df.parse(arrivalDate)));

			schedule.setArrivalTime(date);

			// Parse the date
			Date date1 = df.parse(df.format(df.parse(departureDate)));
			schedule.setDepartureTime(date1);
			
			
			
		} catch (Exception e) {
			System.out.println("Enter the correct date");
			return;
		}

		scheduleflight.setSchedule(schedule);

		this.scheduleFile(scheduleflight);

		// this.serializationSchedule(scheduleList); // initial put null in hashmap ,it
		// will run ONLY one time

	}

	public void serializationSchedule(HashMap<Integer, ScheduledFlight> hm) {

		File path = new File(
				LocationInfo.pathScheduleFligth);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(hm);
			fos.close();
			out.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void scheduleFile(ScheduledFlight scheduleflight) {

		HashMap<Integer, ScheduledFlight> hm = null;

		hm = this.deserializtionSchedule();

		hm.put(scheduleflight.getFlight().getFlightNumber(), scheduleflight);

		this.serializationSchedule(hm);
		System.out.println("Flight Added Successfuly!!");

	}

	public HashMap<Integer, ScheduledFlight> deserializtionSchedule() {

		File path = new File(
				LocationInfo.pathScheduleFligth);

		FileInputStream fis = null;
		FileOutputStream fos = null;
		HashMap<Integer, ScheduledFlight> hm = null;
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			hm = (HashMap<Integer, ScheduledFlight>) in.readObject();
			in.close();
			fis.close();
		} catch (Exception e) {
			System.out.println(e);
			e.setStackTrace(null);
		}

		return hm;
	}

//-----------------------------------------------------END SCHEDULE FLIGHT---------------------------------

	public void searchScheduledFlight(Integer b) {

		HashMap<Integer, ScheduledFlight> hm = this.deserializtionSchedule();
		System.out.println(
				"FlightID  SourceAirport DestinationAirport ArrivalTime DepartureTime TicketCost");
		for (Map.Entry m : hm.entrySet()) {

			if (m.getKey().equals(b)) {
			      ScheduledFlight sf = (ScheduledFlight) m.getValue();
			System.out.println(m.getKey()+"  "+sf.getSchedule().getSourceAirport()+"  "+sf.getSchedule().getDestinationAirport()+"  "
					+ ""+sf.getSchedule().getArrivalTime()+"  "+sf.getSchedule().getDepartureTime()+"  "+sf.getSchedule().getTicketCost());
				return;

			}
		}

		System.out.println("Flight do not exists:");

	}

	public void viewScheduledFlight() {

		HashMap<Integer, ScheduledFlight> hm = this.deserializtionSchedule();
		System.out.println(
				"FlightID  SourceAirport DestinationAirport ArrivalTime DepartureTime TicketCost");
		for (Map.Entry m : hm.entrySet()) {
			      ScheduledFlight sf = (ScheduledFlight) m.getValue();
			System.out.println(m.getKey()+"  "+sf.getSchedule().getSourceAirport()+"  "+sf.getSchedule().getDestinationAirport()+"  "
					+ ""+sf.getSchedule().getArrivalTime()+"  "+sf.getSchedule().getDepartureTime()+"  "+sf.getSchedule().getTicketCost());

		}

	}

//delete scheduleflight from hashmap

	public void deleteFlight(Integer a) {
		HashMap<Integer, ScheduledFlight> hm = this.deserializtionSchedule();

		for (Map.Entry m : hm.entrySet()) {

			if (m.getKey().equals(a)) {
				hm.remove(m.getKey());
				this.serializationSchedule(hm);
				System.out.println("Flight deleted successfully!!");
				return;

			}
		}

		System.out.println("Flight do not exists:");

	}

}
