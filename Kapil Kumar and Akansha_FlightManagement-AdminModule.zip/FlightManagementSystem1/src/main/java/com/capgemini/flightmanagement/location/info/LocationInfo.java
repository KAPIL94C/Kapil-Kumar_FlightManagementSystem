package com.capgemini.flightmanagement.location.info;

public class LocationInfo {
	public static String pathFligth="C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Kapil\\FlightManagementSystem1\\src\\main\\resources\\flight.txt";
	public static String pathScheduleFligth="C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Kapil\\FlightManagementSystem1\\src\\main\\resources\\scheduleflight.txt";
	
}
